<?php

namespace YoastSEO_Vendor;

\define(__NAMESPACE__ . '\RUCKUSING_VERSION', '1.1.0');
